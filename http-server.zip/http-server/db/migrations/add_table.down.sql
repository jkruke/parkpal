DROP TABLE IF EXISTS parking_lots;
